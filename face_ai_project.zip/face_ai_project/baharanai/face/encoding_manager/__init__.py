def encoding_manager_loader(name, config=None, config_path=None):
    if name == 'pickle':
        from .pickle_.pickle_manager import PickleEncodingManager
        manager = PickleEncodingManager(config=config, config_path=config_path)
    elif name == 'redis':
        from .redis_.redis_ import RedisEncodingManager
        manager = RedisEncodingManager(config=config, config_path=config_path)
    else:
        raise Exception('Requested manager is not implemented yet, available managers are: [pickle, redis]')
    return manager
