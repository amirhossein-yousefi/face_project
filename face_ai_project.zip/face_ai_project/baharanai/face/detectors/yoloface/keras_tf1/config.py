model_cfg = "cfg/yolov3-face.cfg"
model_weights = "model-weights/yolov3-wider_16000.weights"
image = ""
video = ""
src = ""
output_dir = "outputs/"
conf_threshold = 0.5
nms_threshold = 0.4
