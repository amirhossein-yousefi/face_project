from keras.models import load_model
from baharanai.face.encoders.main.face_encoder import FaceEncoder
from baharanai.preprocessing.image import resize_images, standard_normalize, l2_normalizer


class FaceNetEncoderKeras(FaceEncoder):
    def __init__(self, config=None, config_path=None):
        super().__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model = load_model(self.config['model_path'])

    def get_encoding(self, batch_face, batch_size=32, do_preprocess=False):
        if do_preprocess:
            batch_face = self.preprocess(batch_face)
        encodes = self._model.predict(batch_face)
        encodes = l2_normalizer.transform(encodes)
        return encodes

    def preprocess(self, batch_face):
        batch_face = standard_normalize(batch_face, batch=True)
        batch_face = resize_images(batch_face, target_size=self.config['input_size'])
        return batch_face

    def load_encoder_info(self):
        self.model_info['output_shape'] = int(self._model.output.shape[-1])
