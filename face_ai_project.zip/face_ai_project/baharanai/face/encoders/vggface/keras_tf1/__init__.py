from .vggface_keras_tf1 import VGGFaceEncoder


del vggface_keras_tf1
