model_path = "H:\\baharan\\face_projects\\face-recognition\\src\\ai\\encoders\\facenet\\keras_tf1\\src\\pretrained\\facenet_keras.h5"
output_shape = 128
input_size = [160, 160]
