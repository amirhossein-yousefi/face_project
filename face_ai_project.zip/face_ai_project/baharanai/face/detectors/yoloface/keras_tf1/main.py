import os
from baharanai.face.detectors.main.detector_main import FaceDetector
import json

from .utils import *


class YOLOFace(FaceDetector):

    def __init__(self, config=None, config_path=None):
        self.config = self.read_json(config_path)
        super(YOLOFace, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self, **kwargs):
        self._model = cv2.dnn.readNetFromDarknet(self.get_relative_path(self.config["model_cfg"]),
                                                 self.get_relative_path(self.config["model_weights"]))
        self._model.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self._model.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)

    def detect_faces(self, frame, *args, **kwargs):

        blob = cv2.dnn.blobFromImage(frame, 1 / 255, (IMG_WIDTH, IMG_HEIGHT), [0, 0, 0], 1, crop=False)
        # Sets the input to the network
        self._model.setInput(blob)

        # Runs the forward pass to get output of the output layers
        outs = self._model.forward(get_outputs_names(self._model))

        # Remove the bounding boxes with low confidence
        faces, confidences = post_process(frame, outs, self.config["conf_threshold"], self.config["nms_threshold"])
        self._boxes = faces
        self._probabilities = confidences
        # we could not found facial_landmarks for YOLOFace
        return self.boxes

    @staticmethod
    def read_json(path):
        with open(path, 'r') as JSON:
            data = json.load(JSON)
        return data

    def box_to_points(self, box):
        x1, y1, width, height = box
        x2, y2 = x1 + width, y1 + height
        pt1, pt2 = (x1, y1), (x2, y2)
        return pt1, pt2

    @staticmethod
    def get_relative_path(name):
        path = os.path.abspath(__file__)
        path = os.path.split(path)[0]
        return os.path.join(path, name)
