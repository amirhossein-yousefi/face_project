net_depth = 50
drop_ratio = 0.6
augmentation = True
output_shape = 512
net_mode = "ir_se"
device = "cpu"
input_size = [
                 112,
                 112
             ],
model_path = "H=\\baharan\\face_projects\\face-recognition\\src\\ai\\encoders\\arc_face\\pytorch\\pretrained\\model_final.pth",
normalize = [
    [
        0.5,
        0.5,
        0.5
    ],
    [
        0.5,
        0.5,
        0.5
    ]
]
