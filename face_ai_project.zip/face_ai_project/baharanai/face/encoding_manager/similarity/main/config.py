similarity_func = "cosine"
