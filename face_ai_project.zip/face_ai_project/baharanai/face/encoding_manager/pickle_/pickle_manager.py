import os
from baharanai.face.encoding_manager.main.encoding_manager import EncodingManager
from baharanai.preprocessing.utils import load_pickle, save_pickle


class PickleEncodingManager(EncodingManager):
    def __init__(self, config=None, config_path=None):
        super().__init__(config=config,
                         config_path=config_path,
                         subclass_path=__file__)

    def connect(self):
        path = self.config['connect']['encode_path']
        if not os.path.exists(path):
            encodings = dict()
        else:
            encodings = load_pickle(path)
        return encodings

    def set_encoding(self, name, encode):
        self._connection[name] = encode

    def get_encoding(self, name):
        if len(name) == 1:
            encode = self._connection[name]
            return encode
        elif len(name) > 1:
            encoding_lst = [self._connection[name_] for name_ in name]
            return encoding_lst

    def _get_all(self, mode='all'):
        if self.ids is None and self.encodings is None:
            self.ids = list(self._connection.keys())
            self.encodings = list(self._connection.values())
        return zip(self.ids, self.encodings)

    def finish_saving(self):
        save_pickle(self.config['connect']['encode_path'], self._connection)

    def compare(self, target_encode):
        min_similarity = float('inf')
        name = self.config['unknown_name']
        for name_, encode in self._get_all():
            similarity = self.similarity_manager.get_similarity(encode, target_encode)
            similarity *= self.mode_coef
            if similarity < self.config['compare_threshold']:
                if similarity < min_similarity:
                    name = name_
                    min_similarity = similarity
        return name, min_similarity
