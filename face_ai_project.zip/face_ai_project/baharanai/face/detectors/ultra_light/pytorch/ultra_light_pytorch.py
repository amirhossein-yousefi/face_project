import numpy as np
from baharanai.face.detectors.main import FaceDetector
from baharanai.preprocessing.image import bgr2rgb, box_to_points
from .vision.ssd.config.fd_config import define_img_size
from .vision.ssd.mb_tiny_fd import create_mb_tiny_fd, create_mb_tiny_fd_predictor
from .vision.ssd.mb_tiny_RFB_fd import create_Mb_Tiny_RFB_fd, create_Mb_Tiny_RFB_fd_predictor


class UltraLightDetectorPytorch(FaceDetector):
    def __init__(self, config=None, config_path=None):
        super().__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        inner_config = define_img_size(self.config['input_size'])
        class_names = [name.strip() for name in open(self.config["label_path"]).readlines()]
        if self.config['net_type'] == 'slim':
            net = create_mb_tiny_fd(len(class_names), config=inner_config, is_test=True, device=self.config['device'])
            predictor = create_mb_tiny_fd_predictor(net, config=inner_config,
                                                    candidate_size=self.config['candidate_size'],
                                                    device=self.config['device'])
        elif self.config['net_type'] == 'RFB':
            net = create_Mb_Tiny_RFB_fd(len(class_names), config=inner_config, is_test=True,
                                        device=self.config['device'])
            predictor = create_Mb_Tiny_RFB_fd_predictor(net, config=inner_config,
                                                        candidate_size=self.config['candidate_size'],
                                                        device=self.config['device'])
        net.load(self.config["model_path"])
        self._model = predictor

    def preprocessing(self, frame, **kwargs):
        is_rgb = kwargs.get('is_rgb', True)
        if not is_rgb:
            frame = bgr2rgb(frame)
        return frame

    def detect_faces(self, image, get_pt=False, **kwargs):

        frame = self.preprocessing(image, **kwargs)
        boxes, _, probs = self._model.predict(frame,
                                              self.config["candidate_size"] / 2,
                                              self.config["confidence"])

        boxes = boxes.detach().numpy().astype(np.int).tolist()
        self._boxes = [[x1, y1, x2 - x1, y2 - y1] for x1, y1, x2, y2 in boxes]
        self._probabilities = probs.detach().numpy().tolist()
        if get_pt:
            return [box_to_points(box) for box in self._boxes]
        else:
            return self.boxes
