import torch
from torchvision import transforms as trans
from .model import Backbone
from baharanai.face.encoders.main.face_encoder import FaceEncoder
from baharanai.preprocessing.image import resize_img, img_to_array, cv2_frame_to_pil
from baharanai.preprocessing.utils.utils import l2_norm_torch


class ArcFacePyTorch(FaceEncoder):
    def __init__(self, config=None, config_path=None):
        super(ArcFacePyTorch, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model = Backbone(self.config['net_depth'],
                               self.config['drop_ratio'],
                               self.config['net_mode']).to(self.config['device'])
        if self.config['device'] == 'cpu':
            self._model.load_state_dict(torch.load(self.config["model_path"], map_location=self.config['device']))
        else:
            self._model.load_state_dict(torch.load(self.config["model_path"]))
        self._model.eval()

    def get_encoding(self, batch_face, do_preprocess=False, **kwargs):
        if self.config['augmentation']:
            faces = []
            for face in batch_face:
                if str(type(face)) != "<class 'PIL.Image.Image'>":
                    face = cv2_frame_to_pil(face, is_rgb=True)
                mirror = trans.functional.hflip(face)
                faces.extend([img_to_array(face), img_to_array(mirror)])
            # faces = np.stack(faces)
        else:
            faces = batch_face
        if do_preprocess:
            faces = self.preprocess(faces)

        if self.config['augmentation']:
            embeddings = self.model(faces.to(self.config['device'])).detach()
            embeddings = [l2_norm_torch(embeddings[2 * i] + embeddings[2 * i + 1], axis=0).numpy() for i in
                          range(embeddings.shape[0] // 2)]
            # instead of averaging source code applies l2_norm ???
        else:
            embeddings = self.model(faces.to(self.config['device'])).detach().numpy()

        return embeddings

    def preprocess(self, batch_face):
        faces = []
        for face in batch_face:
            if face.shape[:2] != tuple(self.config['input_size']):
                face = resize_img(face, self.config['input_size'])
            # face = img_to_array(face)
            face = trans.Compose([
                trans.ToTensor(),
                trans.Normalize(*self.config["normalize"])
            ])(face)
            faces.append(face)
        faces = torch.stack(faces)
        return faces

    def load_encoder_info(self):
        self.model_info['output_shape'] = self.config['output_shape']
