model_path_prototxt="D:\\myprojects\\PycharmProjects\\framework\\baharanai\\face\\mask_detector\\ssd\\caffe\\weights\\face_mask_detection.prototxt"
model_path="D:\\myprojects\\PycharmProjects\\framework\\baharanai\\face\\mask_detector\\ssd\\caffe\\weights\\face_mask_detection.caffemodel"
conf_thresh = 0.5
iou_thresh = 0.4
target_shape = (260, 260)