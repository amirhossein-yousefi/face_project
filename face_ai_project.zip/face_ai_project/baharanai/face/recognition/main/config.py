align = False
decoder = dict(
    name="haarcascade_opencv"
)
encoder = dict(
    name="facenet_keras_tf1"
)
encoding_manager = dict(
    name="pickle",
    config=dict(
        compare_mode="min",
        compare_threshold=0.3,
        unknown_name="unknown",
        similarity=dict(
            config=dict(
                config_func="cosine"
            )
        ),
        connect=dict(
            encode_path=None
        )
    )
)
