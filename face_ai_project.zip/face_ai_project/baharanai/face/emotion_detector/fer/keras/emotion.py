from statistics import mode
from baharanai.preprocessing.utils.datasets import get_labels
from baharanai.preprocessing.utils.inference import apply_offsets
from baharanai.preprocessing.utils.preprocessor import preprocess_input
import numpy as np
from keras.models import load_model
from baharanai.face.emotion_detector.main.emotion_main import EmotionDetector
import  cv2
MODEL_MEAN_VALUES = (78.4263377603, 87.7689143744, 114.895847746)
age_list = ['(0, 2)', '(4, 6)', '(8, 12)', '(15, 20)', '(25, 32)', '(38, 43)', '(48, 53)', '(60, 100)']
gender_list = ['Male', 'Female']


class Emotion(EmotionDetector):
    def __init__(self, config=None, config_path=None):
        super(Emotion, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model=load_model(self.config['model_path'])

    def detect_emotions(self,frame,face,**kwargs):
        emotion_net=self._model
        frame_window = 10
        emotion_window = []
        emotion_offsets = (20, 40)
        emotion_target_size = emotion_net.input_shape[1:3]
        emotion_labels = get_labels('fer2013')
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # if (len(face) > 0):
        #     print("Found {} faces".format(str(len(face))))
        emotion_msg=[]
        # for face in faces:
        (x, y, w, h)=face
        x1, x2, y1, y2 = apply_offsets((x, y, w, h), emotion_offsets)
        gray_face = gray[y1:y2, x1:x2]
        gray_face = cv2.resize(gray_face, emotion_target_size)
        gray_face = preprocess_input(gray_face, True)
        gray_face = np.expand_dims(gray_face, 0)
        gray_face = np.expand_dims(gray_face, -1)
        emotion_prediction = emotion_net.predict(gray_face)
        emotion_probability = np.max(emotion_prediction)
        emotion_label_arg = np.argmax(emotion_prediction)
        emotion_text = emotion_labels[emotion_label_arg]
        emotion_window.append(emotion_text)

        if len(emotion_window) > frame_window:
            emotion_window.pop(0)
        emotion_mode = mode(emotion_window)
        # Below lines of code is to color the bounding boxes for different emotions
        # if emotion_text == 'angry':
        #     color = emotion_probability * np.asarray((255, 0, 0))
        # elif emotion_text == 'sad':
        #     color = emotion_probability * np.asarray((0, 0, 255))
        # elif emotion_text == 'happy':
        #     color = emotion_probability * np.asarray((255, 255, 0))
        # elif emotion_text == 'surprise':
        #     color = emotion_probability * np.asarray((0, 255, 255))
        # else:
        #     color = emotion_probability * np.asarray((0, 255, 0))
        #
        # color = color.astype(int)
        # color = color.tolist()
        # emotion_dict={i:[emotion_mode , face] }
        # emotion_dict =dict()
        # emotion_dict['emotion'] = emotion_mode
        # emotion_dict['box'] = face
        # emotion_msg.append(emotion_dict)
            # i+=1
            # cv2.rectangle(frame, (x, y), (x + w, y + h), 2)  # Get Face
            # print("you are " + emotion_mode)
            # overlay_text = "%s  " % ( emotion_mode)
        # self._probabilitiy = probabilities.append(emotion_probability)
        return emotion_mode
        # cv2.putText(frame, overlay_text, (x, y), font, 1, (255, 255, 255), 2, cv2.LINE_AA)
        # cv2.imshow('frame', frame)



