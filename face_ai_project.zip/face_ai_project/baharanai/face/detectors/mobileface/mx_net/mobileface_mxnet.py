from __future__ import absolute_import

import cv2
import dlib
import mxnet as mx
from gluoncv.data.transforms import presets

from baharanai.face.detectors.main import FaceDetector
from baharanai.face.detectors.mobileface.mx_net.mobileface_detector import MobileFaceDetection
from baharanai.face.detectors.mobileface.mx_net.mobilefacedetnet import mobilefacedetnet_v2
from baharanai.face.detectors.mobileface.mx_net.utils.data_presets import data_trans
from baharanai.face.detectors.mobileface.mx_net.MobileFace_Align.mobileface_alignment import MobileFaceAlign
class mobilefacedetectormxnet(FaceDetector):
    def __init__(self, config=None, config_path=None):
        super(mobilefacedetectormxnet, self).__init__(subclass_path=__file__, config=config, config_path=config_path)
    def load_model(self):
        self.model=self.config["model_path"]
        self.ctx =[mx.gpu(int(i)) for i in ''.split(',') if i.strip()]
        self.ctx = [mx.cpu()] if not self.ctx else self.ctx
        self.net = mobilefacedetnet_v2(self.model)
        ########## Set non-maximum suppression parameters.############
        self.net.set_nms(self.config['nms_thresh'],self.config['nms_topk'])
        self.net.collect_params().reset_ctx(ctx=self.ctx)
        self._model = self.net

    def detect_faces(self, img, get_pt=True, **kwargs):
        #:param get_pt: if true it will return pt1, pt2 instead of x1, y1, width, height
        img_short=self.config['img_short']
        x, img = presets.yolo.transform_test(img, short=img_short)
        x = x.as_in_context(self.ctx[0])
        result = self.net(x)
        ids, scores, bboxes = [xx[0].asnumpy() for xx in result]
        # if get_pt:
        #     return bboxes[bboxes != -1]
        return result

    def landmarks(self, img):
        model_detect=self.config["model_detect_path"]
        model_landmark=self.config["model_landmark_path"]
        model_detect = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mobileface\mx_net\mobileface_detection\model\mobilefacedet_v1_gluoncv.params'
        # model_landmark = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mobileface\mx_net\mobileface_landmark\mobileface_landmark_emnme_v1.dat'
        gpus = ''
        pretrained = 'True'
        thresh = self.config['threshold']
        landmark_num = self.config['landmark_num']  # the version of v1 support 5 or 3 now
        landmark_num=5
        bboxes_predictor = MobileFaceDetection(model_detect, gpus)
        landmark_predictor = dlib.shape_predictor(model_landmark)
        results = bboxes_predictor.mobileface_detector( mx.nd.array(img))
        for i, result in enumerate(results):
            xmin, ymin, xmax, ymax, score, classname = result
            # The landmarks predictor is not trained with union the detector of the mobilefacedet above.
            # Therefore, we need to make some adjustments to the original detection results
            # to adapt to the landmarks predictor.
            size_scale = 0.75
            center_scale = 0.1
            center_shift = (ymax - ymin) * center_scale
            w_new = (ymax - ymin) * size_scale
            h_new = (ymax - ymin) * size_scale
            x_center = xmin + (xmax - xmin) / 2
            y_center = ymin + (ymax - ymin) / 2 + center_shift
            x_min = int(x_center - w_new / 2)
            y_min = int(y_center - h_new / 2)
            x_max = int(x_center + w_new / 2)
            y_max = int(y_center + h_new / 2)

            dlib_box = dlib.rectangle(x_min, y_min, x_max, y_max)
            shape = landmark_predictor(img, dlib_box)
            points = []
            for k in range(landmark_num):
                points.append([shape.part(k).x, shape.part(k).y])
            for k in range(landmark_num):
                cv2.circle(img, (shape.part(k).x, shape.part(k).y), 1, (255, 0, 0), 2, 8, 0)
        cv2.imshow('result', img)
        cv2.waitKey(0)

    def align(self, img):
        model_detect = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mobileface\mx_net\mobileface_detection\model\mobilefacedet_v1_gluoncv.params'
        model_landmark = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mobileface\mx_net\mobileface_landmark\mobileface_landmark_emnme_v1.dat'
        model_align = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mobileface\mx_net\MobileFace_Align\mobileface_align_v1.npy'
        # model_detect=self.config["model_detect_path"]
        model_landmark=self.config["model_landmark_path"]
        model_align=self.config["model_align"]
        gpus = self.config["device"]
        landmark_num = self.config['landmark_num']  # the version of v1 support 5 or 3 now
        # align_size = (96, 96) # the face image size after alined
        align_size = (112, 112)  # the face image size after alined
        bboxes_predictor = MobileFaceDetection(model_detect, gpus)
        landmark_predictor = dlib.shape_predictor(model_landmark)
        align_tool = MobileFaceAlign(model_align)
        results = bboxes_predictor.mobileface_detector(mx.nd.array(img))
        for i, result in enumerate(results):
            xmin, ymin, xmax, ymax, score, classname = result
            # The landmarks predictor is not trained with union the detector of the mobilefacedet above.
            # Therefore, we need to make some adjustments to the original detection results
            # to adapt to the landmarks predictor.
            size_scale = 0.75
            center_scale = 0.1
            center_shift = (ymax - ymin) * center_scale
            w_new = (ymax - ymin) * size_scale
            h_new = (ymax - ymin) * size_scale
            x_center = xmin + (xmax - xmin) / 2
            y_center = ymin + (ymax - ymin) / 2 + center_shift
            x_min = int(x_center - w_new / 2)
            y_min = int(y_center - h_new / 2)
            x_max = int(x_center + w_new / 2)
            y_max = int(y_center + h_new / 2)

            dlib_box = dlib.rectangle(x_min, y_min, x_max, y_max)
            shape = landmark_predictor(img, dlib_box)
            points = []
            for k in range(landmark_num):
                points.append([shape.part(k).x, shape.part(k).y])

            align_points = []
            align_points.append(points)
            align_result = align_tool.get_align(img, align_points, align_size)
        return align_result

    def box_to_points(self, box):
        x1, y1, x2, y2 = box
        pt1, pt2 = (x1, y1), (x2, y2)
        return pt1, pt2
