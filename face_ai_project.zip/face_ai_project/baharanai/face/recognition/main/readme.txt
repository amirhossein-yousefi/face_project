While watching workflow I learned that in most of them they use Kafka as their file transfer manager and
most importantly for face recognition the process of detection and encoding are separate tasks and each of are done in
it's own docker container for simplicity we have add both in one module but after adding kafka to api we need to separate
them ...