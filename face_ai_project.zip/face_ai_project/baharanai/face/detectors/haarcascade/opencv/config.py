model_path = r"/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/detectors/mydem/haracascade/pretrained/haarcascade_frontalface_default.xml"
align = False
scalefactor=1.1
min_neighbors=3