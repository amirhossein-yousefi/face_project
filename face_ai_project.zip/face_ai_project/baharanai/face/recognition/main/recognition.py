from baharanai.face.encoders import face_encoder_loader
from baharanai.face.detectors import face_detector_loader
from baharanai.face.encoding_manager import encoding_manager_loader
from baharanai.preprocessing.utils import load_config
from baharanai.preprocessing.image import crop_face


class FaceRecognizer:
    def __init__(self, config=None, config_path=None):
        self.config = load_config(config=config, config_path=config_path, base_path=__file__)
        self.face_detector = face_detector_loader(**self.config['decoder'])
        self.face_encoder = face_encoder_loader(**self.config['encoder'])
        self.encode_manager = encoding_manager_loader(**self.config['encoding_manager'])

    def run(self, frame):
        boxes = self.face_detector.detect_faces(frame, get_pt=True)
        if len(boxes) == 0:
            return [], [], []
        if self.config['align']:
            cropped_faces = [self.face_detector.align(frame, landmark) for landmark in
                             self.face_detector.facial_landmarks]
        else:
            cropped_faces = [crop_face(frame, box[0], box[1]) for box in boxes]
        encodes = self.face_encoder.get_encoding(cropped_faces, do_preprocess=True)
        names, similarities = [], []
        for encode in encodes:
            name, similarity = self.encode_manager.compare(encode)
            names.append(name)
            similarities.append(similarity)
        return boxes, names, similarities
