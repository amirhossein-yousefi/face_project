compare_mode = "min"
compare_threshold = 0.3
unknown_name = "unknown"
similarity = dict(
    config=None,
    config_path=None
)
connect = dict(encode_path=None)
