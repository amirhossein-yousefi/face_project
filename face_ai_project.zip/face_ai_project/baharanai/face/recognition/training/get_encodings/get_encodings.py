import os
import numpy as np
from baharanai.preprocessing.image import read_image
from baharanai.face.encoders import face_encoder_loader
from baharanai.face.encoding_manager import encoding_manager_loader
from baharanai.preprocessing.utils import load_config
from baharanai.preprocessing.image import l2_normalizer


class GetFaceEncoding:
    """
    This class is just combines combining the encoder and some reading functionality
    It may be removed in future...
    """

    def __init__(self, config=None, config_path=None):
        self.config = load_config(config=config, config_path=config_path, base_path=__file__)
        self.face_encoder = face_encoder_loader(name=self.config['encoder']['name'],
                                                config=self.config['encoder'].get('config'),
                                                config_path=self.config['encoder'].get('config_path'))
        self.encoding_manager = encoding_manager_loader(name=self.config['encoding_manager']['name'],
                                                        config=self.config['encoding_manager'].get('config'),
                                                        config_path=self.config['encoding_manager'].get('config_path'))

    def preprocess(self, batch_face, add_axis=False):
        if add_axis:
            batch_face = np.expand_dims(batch_face, axis=0)
        """
        No preprocessing comes to my mind right now :D
        """
        return batch_face

    def get_encoding(self, batch_face, add_axis=False):
        batch_face = self.preprocess(batch_face, add_axis)
        encodes = self.face_encoder.get_encoding(batch_face, do_preprocess=True)
        return encodes

    def run(self):
        """
        Another encode_storage_mode we shall try is the pos specific encode, averaging may mitigate the accuracy of pos
        variation and illumination variations so it's a good practice to save all encodes of different poses
        and illuminations for a face to use in future distance measuring...
        """

        if self.config['input_mode'] == 'folder_id':
            for face_name in os.listdir(self.config['read_path']):
                face_folder_path = os.path.join(self.config['read_path'], face_name)
                encodings = list()
                # we want to average upcoming encodes so we need to sum them
                for file_name in os.listdir(face_folder_path):
                    file_path = os.path.join(face_folder_path, file_name)
                    try:
                        face = read_image(img_path=file_path, ret_rgb=True)
                        new_encoding = self.get_encoding(batch_face=face, add_axis=True)[0]
                        encodings.append(new_encoding)
                        print(file_path, '  saved')
                    except BaseException as error:
                        print(f'{file_path} is not a pick')
                        print(error)
                if len(encodings) == 0:
                    continue

                if self.config["encode_gather_mode"] == 'avg':
                    encoding = np.mean(np.array(encodings), axis=0)
                elif self.config["encode_gather_mode"] == 'l2_norm':
                    encodings = np.sum(np.array(encodings), axis=0)
                    encoding = l2_normalizer.transform(encodings.reshape((1, -1)))[0]
                else:
                    raise Exception('right now only avg mode is available')
                self.encoding_manager.set_encoding(face_name, encoding)
            self.encoding_manager.finish_saving()
        else:
            raise Exception('right now only folder_id mode is implemented for input_mode')
