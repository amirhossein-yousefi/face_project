from baharanai.face.encoders.main.face_encoder import FaceEncoder
import cv2


class FaceNetEncoder(FaceEncoder):
    def __init__(self, config=None, config_path=None):
        super(FaceNetEncoder, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model = cv2.dnn.readNetFromTorch(self.config["model_path"])

    def get_encoding(self, batch_face, batch_size=32, do_preprocess=False):
        if do_preprocess:
            batch_face = self.preprocess(batch_face)
        face_blob = cv2.dnn.blobFromImages(batch_face,
                                          self.config['blob_image']['scale_factor'],
                                          tuple(self.config['blob_image']['size']),
                                          self.config['blob_image']['swapRB'],
                                          self.config['blob_image']['crop'])
        self._model.setInput(face_blob)
        vec = self._model.forward()
        return vec

    def preprocess(self, batch_face):
        # batch_face = img_to_array(batch_face, dtype='float32')
        return batch_face

    def load_encoder_info(self):
        self.model_info['output_shape'] = self.config['output_shape']
