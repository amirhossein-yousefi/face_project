from datetime import datetime
import numpy as np
import redis
from baharanai.face.encoding_manager.main.encoding_manager import EncodingManager


class RedisEncodingManager(EncodingManager):
    def __init__(self, config=None, config_path=None):
        super().__init__(config=config,
                         config_path=config_path,
                         subclass_path=__file__)
        self.last_update = None

    def connect(self):
        redis_manager = redis.Redis(**self.config['connect'])
        return redis_manager

    def _get_key(self, input_):
        return self.config['id_var'] + ":" + input_

    def set_encoding(self, name, encoding):
        """Store given Numpy array 'a' in Redis under key 'n'"""
        encoded = encoding.tostring()
        self._connection.set(self._get_key(name), encoded)

    def _get_encode(self, name):
        encoded = self._connection.get(name)
        encoding = np.fromstring(encoded, dtype=self.config['encoding_dtype'])
        return encoding

    def get_encoding(self, name):
        if type(name) not in [list, tuple]:
            encode = self._get_encode(name)
            return encode
        elif type(name) in [list, tuple]:
            encoding_lst = [self._get_encode(name_) for name_ in name]
            return encoding_lst
        raise Exception(f"expected list type for not >> name: {type(name)}")

    def _get_all(self, mode='all'):
        if mode == 'ids':
            last_update = self._connection.get(self.config['update_var']).decode()
            last_update = datetime.strptime(last_update, '%Y-%m-%d %H:%M:%S.%f')
            if self.last_update is None or last_update > self.last_update:
                self.ids = [id_.decode() for id_ in self._connection.keys(self.config['id_var'] + ":*")]
                self.last_update = datetime.now()
            return self.ids

    def finish_saving(self):
        now = str(datetime.now())
        self._connection.set(self.config['update_var'], now)
        self._connection.bgsave()

    def compare(self, target_encode):
        min_similarity = float('inf')
        name = self.config['unknown_name']
        for name_ in self._get_all(mode='ids'):
            encoding = self.get_encoding(name_)
            similarity = self.similarity_manager.get_similarity(encoding, target_encode)
            similarity *= self.mode_coef
            if similarity < self.config['compare_threshold']:
                if similarity < min_similarity:
                    name = name_
                    min_similarity = similarity
        return name, min_similarity
