gender_prot_model = r"/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/gender/gender_opencv/pretrained/deploy_gender.prototxt"
gender_caffe_model = r"/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/gender/gender_opencv/pretrained/gender_net.caffemodel"
face_path="D:\\PycharmProjects\\opencvgen\model\\haarcascade_frontalface_default.xml"
