

import cv2
import time
# import caffe
import argparse
import numpy as np
from PIL import Image
from baharanai.preprocessing.utils.anchor_generator import generate_anchors
from baharanai.preprocessing.utils.anchor_decode import decode_bbox
from baharanai.preprocessing.utils.nms import single_class_non_max_suppression
from baharanai.face.mask_detector.ssd.caffe.load_model.caffe_loader import load_caffe_model, caffe_inference
from baharanai.face.mask_detector.main.mask_main import MaskDetector


class CaffeMask(MaskDetector):
    def __init__(self, config=None, config_path=None):
        super(CaffeMask, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model=load_caffe_model(self.config["model_path_prototxt"],self.config["model_path"])

    def detect_mask(self,image,**kwargs):
        feature_map_sizes = [[33, 33], [17, 17], [9, 9], [5, 5], [3, 3]]
        anchor_sizes = [[0.04, 0.056], [0.08, 0.11], [0.16, 0.22], [0.32, 0.45], [0.64, 0.72]]
        anchor_ratios = [[1, 0.62, 0.42]] * 5
        model=self._model
        anchors = generate_anchors(feature_map_sizes, anchor_sizes, anchor_ratios)

        # for inference , the batch size is 1, the model output shape is [1, N, 4],
        # so we expand dim for anchors to [1, anchor_num, 4]
        anchors_exp = np.expand_dims(anchors, axis=0)

        id2class = {0: 'Mask', 1: 'NoMask'}
        conf_thresh = self.config['conf_thresh']
        iou_thresh = self.config['iou_thresh']
        target_shape = self.config['target_shape']
        output_info = []
        height, width, _ = image.shape
        image_resized = cv2.resize(image, target_shape)
        image_np = image_resized / 255.0  # 归一化到0~1
        image_exp = np.expand_dims(image_np, axis=0)

        y_bboxes_output, y_cls_output = caffe_inference(model, image_exp)
        # remove the batch dimension, for batch is always 1 for inference.
        y_bboxes = decode_bbox(anchors_exp, y_bboxes_output)[0]
        y_cls = y_cls_output[0]
        # To speed up, do single class NMS, not multiple classes NMS.
        bbox_max_scores = np.max(y_cls, axis=1)
        bbox_max_score_classes = np.argmax(y_cls, axis=1)

        # keep_idx is the alive bounding box after nms.
        keep_idxs = single_class_non_max_suppression(y_bboxes,
                                                     bbox_max_scores,
                                                     conf_thresh=conf_thresh,
                                                     iou_thresh=iou_thresh,
                                                     )

        for idx in keep_idxs:
            conf = float(bbox_max_scores[idx])
            class_id = bbox_max_score_classes[idx]
            bbox = y_bboxes[idx]
            # clip the coordinate, avoid the value exceed the image boundary.
            xmin = max(0, int(bbox[0] * width))
            ymin = max(0, int(bbox[1] * height))
            xmax = min(int(bbox[2] * width), width)
            ymax = min(int(bbox[3] * height), height)

            # if draw_result:
            #     if class_id == 0:
            #         color = (0, 255, 0)
            #     else:
            #         color = (255, 0, 0)
            #     cv2.rectangle(image, (xmin, ymin), (xmax, ymax), color, 2)
            #     cv2.putText(image, "%s: %.2f" % (id2class[class_id], conf), (xmin + 2, ymin - 2),
            #                 cv2.FONT_HERSHEY_SIMPLEX, 0.8, color)
            mask_dict =dict()
            mask_dict['mask'] =id2class[class_id]
            mask_dict['box'] = [xmin, ymin, xmax, ymax]
            mask_dict['confidence']=conf
            output_info.append(mask_dict)
        # if show_result:
        #     Image.fromarray(image).show()
        return output_info
        # cv2.putText(frame, overlay_text, (x, y), font, 1, (255, 255, 255), 2, cv2.LINE_AA)
        # cv2.imshow('frame', frame)



