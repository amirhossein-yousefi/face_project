from baharanai.face.encoders.main.face_encoder import FaceEncoder
from baharanai.preprocessing.image import resize_img, img_to_array, cv2_frame_to_pil
from baharanai.preprocessing.utils import l2_norm_torch
from .src.models import senet
import numpy as np
import pickle
import torch
from torchvision import transforms as trans


class VGGFaceEncoderPytorch(FaceEncoder):
    def __init__(self, config=None, config_path=None):
        super(VGGFaceEncoderPytorch, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model = senet.senet50(include_top=False)
        with open(self.config['model_path'], 'rb') as f:
            weights = pickle.load(f, encoding='latin1')
        own_state = self._model.state_dict()
        for name, param in weights.items():
            if name in own_state:
                try:
                    own_state[name].copy_(torch.from_numpy(param))
                except Exception:
                    raise RuntimeError(
                        'While copying the parameter named {}, whose dimensions in the model are {} and whose ' \
                        'dimensions in the checkpoint are {}.'.format(name, own_state[name].size(), param.size()))
            else:
                raise KeyError('unexpected key "{}" in state_dict'.format(name))
        self._model.eval()
        self._model.to(self.config['device'])

    def get_encoding(self, batch_face, do_preprocess, **kwargs):
        if self.config['augmentation']:
            faces = []
            for face in batch_face:
                if str(type(face)) != "<class 'PIL.Image.Image'>":
                    face = cv2_frame_to_pil(face, is_rgb=True)
                mirror = trans.functional.hflip(face)
                faces.extend([img_to_array(face), img_to_array(mirror)])
            # faces = np.stack(faces)
        else:
            faces = batch_face
        if do_preprocess:
            faces = self.preprocess(faces)

        if self.config['augmentation']:
            embeddings = self.model(faces.to(self.config['device'])).detach()
            embeddings = [l2_norm_torch(embeddings[2 * i] + embeddings[2 * i + 1], axis=0).numpy() for i in
                          range(embeddings.shape[0] // 2)]
        else:
            embeddings = self.model(faces.to(self.config['device'])).detach().numpy()
        embeddings = [np.squeeze(np.squeeze(embed, axis=-1), axis=-1) for embed in embeddings]
        return embeddings

        # if do_preprocess:
        #     batch_face = self.preprocess(batch_face)
        # res = self._model(batch_face)
        # res = torch.squeeze(torch.squeeze(res, dim=-1), dim=-1).detach().numpy()
        # return res

    def preprocess(self, batch_face):
        faces = []
        for face in batch_face:
            if face.shape[:2] != tuple(self.config['input_shape'][:2]):
                face = resize_img(face, self.config['input_shape'][:2])
            face = trans.Compose([
                trans.ToTensor(),
                trans.Normalize(*self.config["normalize"])
            ])(face)
            faces.append(face)
        faces = torch.stack(faces)
        return faces

    def load_encoder_info(self):
        """
        This method loads the general information which may be needed for model like output shape
        """
        self.model_info['output_shape'] = self.config['output_shape']
