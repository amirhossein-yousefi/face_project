import numpy as np
import torch
from baharanai.face.detectors.mtcnn_.pytorch.src.box_utils import nms, calibrate_box, get_image_boxes, convert_to_square
from baharanai.face.detectors.mtcnn_.pytorch.src.first_stage import run_first_stage
from baharanai.face.detectors.mtcnn_.pytorch.src.get_nets import PNet, RNet, ONet
from baharanai.face.detectors.main import FaceDetector
from baharanai.preprocessing.image import bgr2rgb, cv2_frame_to_pil
from baharanai.face.detectors.mtcnn_.pytorch.align_trans import get_reference_facial_points, warp_and_crop_face


class MTCNNDetectorPyTorch(FaceDetector):
    def __init__(self, config=None, config_path=None):
        super(MTCNNDetectorPyTorch, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        pnet = PNet(self.config['pnet_weight'])
        rnet = RNet(self.config['rnet_weight'])
        onet = ONet(self.config['onet_weight'])
        pnet.eval()
        rnet.eval()
        onet.eval()

        self._model = dict(pnet=pnet, rnet=rnet, onet=onet)
        self.refrence = get_reference_facial_points(default_square=True)

    def preprocessing(self, frame, is_rgb=True):
        if not is_rgb:
            frame = bgr2rgb(frame)
        return frame

    def align(self, img, landmark, **kwargs):
        """

        :param img: it should be and rgb img
        :param landmark:
        :return: returns an rgb numpy array
        """
        facial5points = [[landmark[j], landmark[j + 5]] for j in range(5)]
        warped_face = warp_and_crop_face(np.array(img),
                                         facial5points,
                                         self.refrence,
                                         crop_size=self.config['crop_size'])
        return np.array(warped_face)

    def detect_faces(self, image, get_pt=False, **kwargs):
        """
        :param image: it should be an RGB and in PIL format
        :param get_pt: if true it will return pt1, pt2 instead of x1, y1, width, height
        :return:
        """

        # width, height = frame.size
        # min_length = min(height, width)

        min_detection_size = self.config['min_detection_size']
        factor = self.config['factor']
        thresholds = self.config['thresholds']
        nms_thresholds = self.config['nms_thresholds']
        device = self.config['device']
        min_face_size = self.config['min_face_size']

        if str(type(image)) != "<class 'PIL.Image.Image'>":
            image = cv2_frame_to_pil(image, is_rgb=True)
        width, height = image.size
        min_length = min(height, width)

        # scales for scaling the image
        scales = []

        # scales the image so that
        # minimum size that we can detect equals to
        # minimum face size that we want to detect
        m = min_detection_size / min_face_size
        min_length *= m

        factor_count = 0
        while min_length > min_detection_size:
            scales.append(m * factor ** factor_count)
            min_length *= factor
            factor_count += 1

        # STAGE 1

        # it will be returned
        bounding_boxes = []
        try:
            with torch.no_grad():
                # run P-Net on different scales
                for s in scales:
                    boxes = run_first_stage(image, self._model["pnet"], scale=s, threshold=thresholds[0])
                    bounding_boxes.append(boxes)

                # collect boxes (and offsets, and scores) from different scales
                bounding_boxes = [i for i in bounding_boxes if i is not None]
                bounding_boxes = np.vstack(bounding_boxes)

                keep = nms(bounding_boxes[:, 0:5], nms_thresholds[0])
                bounding_boxes = bounding_boxes[keep]

                # use offsets predicted by pnet to transform bounding boxes
                bounding_boxes = calibrate_box(bounding_boxes[:, 0:5], bounding_boxes[:, 5:])
                # shape [n_boxes, 5]

                bounding_boxes = convert_to_square(bounding_boxes)
                bounding_boxes[:, 0:4] = np.round(bounding_boxes[:, 0:4])

                # STAGE 2

                img_boxes = get_image_boxes(bounding_boxes, image, size=24)
                img_boxes = torch.FloatTensor(img_boxes).to(device)

                output = self._model["rnet"](img_boxes)
                offsets = output[0].cpu().data.numpy()  # shape [n_boxes, 4]
                probs = output[1].cpu().data.numpy()  # shape [n_boxes, 2]

                keep = np.where(probs[:, 1] > thresholds[1])[0]
                bounding_boxes = bounding_boxes[keep]
                bounding_boxes[:, 4] = probs[keep, 1].reshape((-1,))
                offsets = offsets[keep]

                keep = nms(bounding_boxes, nms_thresholds[1])
                bounding_boxes = bounding_boxes[keep]
                bounding_boxes = calibrate_box(bounding_boxes, offsets[keep])
                bounding_boxes = convert_to_square(bounding_boxes)
                bounding_boxes[:, 0:4] = np.round(bounding_boxes[:, 0:4])

                # STAGE 3

                img_boxes = get_image_boxes(bounding_boxes, image, size=48)
                if len(img_boxes) == 0:
                    return []
                img_boxes = torch.FloatTensor(img_boxes).to(device)
                output = self._model["onet"](img_boxes)
                landmarks = output[0].cpu().data.numpy()  # shape [n_boxes, 10]
                offsets = output[1].cpu().data.numpy()  # shape [n_boxes, 4]
                probs = output[2].cpu().data.numpy()  # shape [n_boxes, 2]

                keep = np.where(probs[:, 1] > thresholds[2])[0]
                bounding_boxes = bounding_boxes[keep]
                bounding_boxes[:, 4] = probs[keep, 1].reshape((-1,))
                offsets = offsets[keep]
                landmarks = landmarks[keep]

                # compute landmark points
                width = bounding_boxes[:, 2] - bounding_boxes[:, 0] + 1.0
                height = bounding_boxes[:, 3] - bounding_boxes[:, 1] + 1.0
                xmin, ymin = bounding_boxes[:, 0], bounding_boxes[:, 1]
                landmarks[:, 0:5] = np.expand_dims(xmin, 1) + np.expand_dims(width, 1) * landmarks[:, 0:5]
                landmarks[:, 5:10] = np.expand_dims(ymin, 1) + np.expand_dims(height, 1) * landmarks[:, 5:10]

                bounding_boxes = calibrate_box(bounding_boxes, offsets)
                keep = nms(bounding_boxes, nms_thresholds[2], mode='min')
                bounding_boxes = bounding_boxes[keep]
                landmarks_ = landmarks[keep]
            # return bounding_boxes, landmarks
        except ValueError as e:
            # print(e)
            self._boxes = []
            return []
        probabilities, boxes, landmarks = [], [], []
        box_extend = self.config['box_extend']
        for (b0, b1, b2, b3, c), landmark in zip(bounding_boxes, landmarks_):
            if c < self.config['min_face_probability']:
                continue
            probabilities.append(c)
            boxes.append(((int(b0) + box_extend[0],
                           int(b1) + box_extend[1]),
                          (int(b2) + box_extend[2],
                           int(b3) + box_extend[3])))
            landmarks.append(landmark)
        self._probabilities = probabilities
        self._facial_landmarks = landmarks
        self._boxes = boxes
        if get_pt:
            return self.boxes
        else:
            boxes = [[abs(x1), abs(y1), abs(x2) - abs(x1), abs(y2) - abs(y1)] for (x1, y1), (x2, y2) in self.boxes]
            return boxes
