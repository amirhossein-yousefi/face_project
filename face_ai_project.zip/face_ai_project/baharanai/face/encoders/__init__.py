def face_encoder_loader(name, config=None, config_path=None):
    if name == 'vggface_keras_tf1':
        from baharanai.face.encoders.vggface.keras_tf1 import VGGFaceEncoder
        face_encoder = VGGFaceEncoder(config=config, config_path=config_path)
    elif name == 'vggface_pytorch':
        from baharanai.face.encoders.vggface.pytorch import VGGFaceEncoderPytorch
        face_encoder = VGGFaceEncoderPytorch(config=config, config_path=config_path)
    elif name == 'arc_face_pytorch':
        from baharanai.face.encoders.arc_face.pytorch import ArcFacePyTorch
        face_encoder = ArcFacePyTorch(config=config, config_path=config_path)
    elif name == 'facenet_opencv_torch':
        from baharanai.face.encoders.facenet.opencv_torch import FaceNetEncoder
        face_encoder = FaceNetEncoder(config=config, config_path=config_path)
    elif name == 'facenet_keras_tf1':
        from baharanai.face.encoders.facenet.keras_tf1 import FaceNetEncoderKeras
        face_encoder = FaceNetEncoderKeras(config=config, config_path=config_path)
    else:
        raise NotImplementedError(f"the requested encoder  {name} is not implemented")
    return face_encoder
