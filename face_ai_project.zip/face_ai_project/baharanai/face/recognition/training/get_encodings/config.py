input_mode = "folder_id"
read_path = None
encode_gather_mode = "l2_norm"
encoder = dict(
    name="vggface_keras_tf1"
)
encoding_manager = dict(
    name="pickle"
)
