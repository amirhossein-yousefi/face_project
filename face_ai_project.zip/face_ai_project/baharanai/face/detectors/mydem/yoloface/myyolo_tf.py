from baharanai.face.detectors.yoloface.keras_tf1.main import YOLOFace
import time
import cv2
from baharanai.preprocessing.image import draw_rectangle, cv2_frame_to_pil, box_to_points,read_image,show_img,crop_face,get_biggest_box
conf_path = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mydem\yoloface\config.json'
img_path = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mydem\data\my3.jpg'
img=read_image(img_path, lib='cv2', ret_rgb=True)
detector=YOLOFace(config_path=conf_path)
boxes=detector.detect_faces(img)
for box in boxes:
    # print(box)
    pt1, pt2 = box_to_points(box)
    img = draw_rectangle(img, pt1, pt2, copy=False, color=(0, 255, 0), is_rgb=True)

box, box1_index = get_biggest_box(boxes, mode='width_height')
pt1, pt2 = box_to_points(box)
face = crop_face(img, pt1, pt2, )
show_img(img, is_rgb=True)
