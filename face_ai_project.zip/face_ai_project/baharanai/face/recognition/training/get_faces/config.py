input_mode = "folder_id"
read_path = None
save_path = None
video_input = False
align = False
detector = dict(
    name="mtcnn_keras_tf1",
    config=None,
    config_path=None
)
