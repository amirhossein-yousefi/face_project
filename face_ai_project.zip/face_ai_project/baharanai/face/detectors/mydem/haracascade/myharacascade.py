from baharanai.face.detectors.haarcascade.opencv.haarcascade import HaarCascadeDetector
from baharanai.preprocessing.image import box_to_points
from baharanai.preprocessing.image import draw_rectangle, show_img, crop_face, get_biggest_box, save_img, read_image
import cv2

img_path = r'D:\myprojects\PycharmProjects\framework\baharanai\face\detectors\mydem\data\my1.jpg'
img = read_image(img_path, lib='cv2', ret_rgb=True)
conf_path=r'D:\myprojects\PycharmProjects\framework\baharanai\face\detectors\mydem\haracascade\config.json'
detector = HaarCascadeDetector(config_path=conf_path)
boxes = detector.detect_faces(img)
for box in boxes:
    pt1, pt2 = box_to_points(box)
    img = draw_rectangle(img, pt1, pt2, copy=False, color=(0, 255, 0), is_rgb=True)
box, box_index = get_biggest_box(boxes)
pt1, pt2 = box_to_points(box)
face = crop_face(img, pt1, pt2, )
show_img(img, is_rgb=True)
cv2.waitKey(10000)
