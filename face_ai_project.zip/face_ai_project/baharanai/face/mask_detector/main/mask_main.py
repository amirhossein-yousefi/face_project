from baharanai.preprocessing.utils.utils import load_config


class MaskDetector:
    """
    All detectors must inherit this Class
    """

    def __init__(self, subclass_path, config=None, config_path=None):
        """
        detector model should be assigned to self.model
        boxes should be assigned to self.boxes
        facial landmarks(if there exists any) should be assigned to self.facial_landmarks
        probabilities, probability of being face should be assigned to self.probabilities
        :param kwargs
        """
        self.subclass_path = subclass_path
        self.config = load_config(config=config, config_path=config_path, base_path=self.subclass_path)
        self._model = None
        self._probabilities = None
        self.load_model()

    def load_model(self):
        """
        This method does not return anything it loads the detector model and assigns it to self.model
        :param kwargs:
        """
        raise NotImplementedError('implement model loading')

    def detect_mask(self, frame, **kwargs):
        """
        returns the detected faces by model
        :param frame: input frame image

        :param kwargs:
        :return: boxes which has been detected in the input frame
        """
        raise NotImplementedError('implement detecting process')


    @property
    def boxes(self):
        return self._boxes

    @property
    def probabilities(self):
        return self._probabilities

