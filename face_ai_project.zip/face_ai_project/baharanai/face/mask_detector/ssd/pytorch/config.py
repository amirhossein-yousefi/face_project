model_path="D:\\myprojects\\PycharmProjects\\framework\\baharanai\\face\\mask_detector\\ssd\\pytorch\\weights\\model360.pth"
conf_thresh = 0.5
iou_thresh = 0.4
target_shape = (360, 360)