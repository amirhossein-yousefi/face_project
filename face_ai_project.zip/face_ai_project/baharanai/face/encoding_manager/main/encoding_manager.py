from baharanai.face.encoding_manager.similarity import Similarity
from baharanai.preprocessing.utils import load_config


class EncodingManager:
    def __init__(self, config=None, config_path=None, subclass_path=None):
        self.subclass_path = subclass_path
        self.config = load_config(config=config, config_path=config_path, base_path=subclass_path)
        self.similarity_manager = Similarity(**self.config.get('similarity', dict()))
        self._connection = self.connect()
        self.ids = None
        self.encodings = None
        self.mode_coef = +1
        self.get_mode_coef()

    def get_mode_coef(self):
        mode = self.config['compare_mode']
        if mode == 'max':
            self.mode_coef = -1
        elif mode == 'min':
            self.mode_coef = +1
        else:
            raise Exception(f'requested compare_mode={mode} is not implemented yet,  available ["min", "max"]')

    def connect(self):
        """
        This method connects to encodings, it can be db or it can be pickle file and ...
        """
        raise NotImplementedError('Not implemented')

    def get_encoding(self, name):
        """
        This method takes a name and outputs the encodings for that name or names
        """
        raise NotImplementedError('Not implemented')

    def set_encoding(self, name, encode):
        """
        This method saves a name and an encode to connection
        """
        raise NotImplementedError('Not implemented')

    def _get_all(self, mode='all'):
        """
        This method returns all the names and encodes, it could be a generator which returns a name and a
        encode or a zipped of names and encodes
        :return: two lists first for names, second for encodings
        """
        raise NotImplementedError('Not implemented')

    def finish_saving(self):
        """In this method the saving process is finalized, like saving pickle to hard-disk and ..."""
        raise NotImplementedError('Not implemented')

    def compare(self, target_encode):
        """In this method the act comparision between two encodings and requested encode(target) will take place"""
        raise NotImplementedError('Not implemented')
