import cv2
from baharanai.face.gender.main.gender_main  import GenderDetector

MODEL_MEAN_VALUES = (78.4263377603, 87.7689143744, 114.895847746)
gender_list = ['Male', 'Female']
class Gender(GenderDetector):
    def __init__(self, config=None, config_path=None):
        super(Gender, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model = cv2.dnn.readNetFromCaffe(prototxt=self.config['gender_prot_model'],caffeModel= self.config['gender_caffe_model'])

    def detect_gender(self, frame,face, **kwargs):
        # detector=HaarCascadeDetector
        gender_net=self._model
        # face_cascade = cv2.CascadeClassifier(self.config['face_path'])
        # gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # faces = face_cascade.detectMultiScale(gray, 1.1, 5)
        (x,y,w,h)=face
        # Below lines of code is to color the bounding boxes for different emotions
        cv2.rectangle(frame, (x, y), (x + w, y + h),  2)  # Get Face
        face_img = frame[y:y + h, h:h + w].copy()
        blob = cv2.dnn.blobFromImage(face_img, 1, (227, 227), MODEL_MEAN_VALUES, swapRB=False)  # Predict Gender
        gender_net.setInput(blob)
        gender_preds = gender_net.forward()
        gender = gender_list[gender_preds[0].argmax()]
        return gender
        # cv2.putText(frame, overlay_text, (x, y), font, 1, (255, 255, 255), 2, cv2.LINE_AA)
        # cv2.imshow('frame', frame)



