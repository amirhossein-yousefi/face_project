import time
import cv2
from baharanai.preprocessing.image import draw_rectangle, cv2_frame_to_pil, box_to_points,read_image,show_img
from baharanai.face.detectors.ultra_light.pytorch.ultra_light_pytorch import UltraLightDetectorPytorch

# if __name__ == '__main__':
detector = UltraLightDetectorPytorch(config_path=r'D:\myprojects\PycharmProjects\framework\baharanai\face\detectors\mydem\ultralight_pytorch\config.json')
#     vc = cv2.VideoCapture(1)
#     while vc.isOpened():
#         ret, frame = vc.read()
#         if not ret:
#             print(':(')
#             break
# img_path = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mydem\data\my1.jpg'
# img = read_image(img_path, lib='cv2', ret_rgb=True)
# tic = time.time()
# boxes = detector.detect_faces(img, is_rgb=False)
# toc = time.time()
# print(f'detect time:{toc - tic}')
# for box in boxes:
#     pt1, pt2 = box_to_points(box)
#     img = draw_rectangle(img, pt1, pt2, copy=False, color=(0, 255, 0), is_rgb=False)
# show_img(img, is_rgb=True)


vc = cv2.VideoCapture(0)
while vc.isOpened():
    ret, frame = vc.read()
    if not ret:
        print(':(')
        break
    tic = time.time()
    boxes = detector.detect_faces(frame, is_rgb=False)
    toc = time.time()
    print(f'detect time:{toc - tic}')
    for box in boxes:
        pt1, pt2 = box_to_points(box)
        frame = draw_rectangle(frame, pt1, pt2, copy=False, color=(0, 255, 0), is_rgb=False)
    cv2.imshow('', frame)
    if cv2.waitKey(1) & 0xff == ord('q'):
        break

