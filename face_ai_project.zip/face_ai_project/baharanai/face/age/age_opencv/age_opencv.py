import cv2
from baharanai.face.age.main.age_main import AgeDetector
MODEL_MEAN_VALUES = (78.4263377603, 87.7689143744, 114.895847746)
age_list = ['(0, 2)', '(4, 6)', '(8, 12)', '(15, 20)', '(25, 32)', '(38, 43)', '(48, 53)', '(60, 100)']

class Age(AgeDetector):
    def __init__(self, config=None, config_path=None):
        super(Age, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model = cv2.dnn.readNetFromCaffe(prototxt=self.config['age_prot_model'],caffeModel= self.config['age_caffe_model'])

    def detect_age(self, frame,face,**kwargs):
        age_net=self._model
        (x,y,w,h)=face
        # Below lines of code is to color the bounding boxes for different emotions
        cv2.rectangle(frame, (x, y), (x + w, y + h),  2)  # Get Face
        face_img = frame[y:y + h, h:h + w].copy()
        blob = cv2.dnn.blobFromImage(face_img, 1, (227, 227), MODEL_MEAN_VALUES, swapRB=False)  # Predict Gender
        age_net.setInput(blob)
        age_preds = age_net.forward()
        age = age_list[age_preds[0].argmax()]
        return age
        # cv2.putText(frame, overlay_text, (x, y), font, 1, (255, 255, 255), 2, cv2.LINE_AA)
        # cv2.imshow('frame', frame)



