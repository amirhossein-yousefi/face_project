net_type = "RFB"
input_size = 480
confidence = 0.9
candidate_size = 1000
device = "cpu"
label_path = "H:\\baharan\\face_projects\\face-recognition\\src\\ai\\detectors\\ultra_light\\pytorch\\models\\voc-model-labels.txt"
model_path = "H:\\baharan\\face_projects\\face-recognition\\src\\ai\\detectors\\ultra_light\\pytorch\\models\\pretrained\\version-RFB-640.pth"
