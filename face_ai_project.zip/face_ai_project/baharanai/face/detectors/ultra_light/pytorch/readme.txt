input_size = 480  # 128/160/320/480/640/1280
threshold = 0.9
candidate_size = 1000  # nms candidate size
device = 'cpu'
net_type = 'slim'  # slim(faster)
RBF: 360 and 640
slim: 360 and 640
net_type and model_path should match