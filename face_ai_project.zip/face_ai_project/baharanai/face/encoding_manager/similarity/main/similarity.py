from baharanai.preprocessing.utils import load_config


class Similarity:
    def __init__(self, config=None, config_path=None):
        self.config = load_config(base_path=__file__, config=config, config_path=config_path)
        self.func = self.load_similarity_func()

    def load_similarity_func(self):
        name = self.config['similarity_func']
        if name == "cosine":
            from scipy.spatial.distance import cosine
            return cosine
        elif name == 'euclidean':
            from scipy.spatial.distance import euclidean
            return euclidean

    def get_similarity(self, base_encode, target_encode):
        """
        Based on the similarity method, which is defined in config file
        :param base_encode:
        :param target_encode:
        :return:
        """
        return self.func(base_encode, target_encode)

    def get_group_similarity(self, base_encodes, target_encodes):
        raise Exception('not implemented')
