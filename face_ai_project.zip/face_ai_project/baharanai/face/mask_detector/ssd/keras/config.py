model_path="/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/mask_detector/ssd/keras/weights/face_mask_detection.hdf5"
model_path_json="/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/mask_detector/ssd/keras/weights/face_mask_detection.json"
conf_thresh = 0.5
iou_thresh = 0.4
target_shape = (260, 260)