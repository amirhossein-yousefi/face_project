from mtcnn import MTCNN
from baharanai.face.detectors.main.detector_main import FaceDetector
from baharanai.preprocessing.image import bgr2rgb, box_to_points


class MTCNNDetectorTF1(FaceDetector):
    def __init__(self, config=None, config_path=None):
        super(MTCNNDetectorTF1, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        """
                Initializes the MTCNN.
                :param weights_file: file uri with the weights of the P, R and O networks from
                MTCNN. By default it will load
                the ones bundled with the package.
                :param min_face_size: minimum size of the face to detect
                :param steps_threshold: step's thresholds values
                :param scale_factor: scale factor
        """

        self._model = MTCNN(self.config['weights_file'],
                            self.config['min_face_size'],
                            self.config['steps_threshold'],
                            self.config['scale_factor'])

    def preprocessing(self, frame, is_rgb=True):
        if not is_rgb:
            frame = bgr2rgb(frame)
        return frame

    def detect_faces(self, frame, get_pt=False, **kwargs):
        """
        :param frame:
        :param get_pt: if true it will return pt1, pt2 instead of x1, y1, width, height
        :return:
        """
        frame = self.preprocessing(frame)
        detect_res = self._model.detect_faces(frame)
        self._boxes = [box['box'] for box in detect_res]
        self._boxes = [[abs(x1), abs(y1), width, height] for x1, y1, width, height in self._boxes]
        # sometimes mtcnn returns negative x1, y1 :(
        self._facial_landmarks = [box['keypoints'] for box in detect_res]
        self._probabilities = [box['confidence'] for box in detect_res]

        boxes, landmarks, probabilities = [], [], []
        for land_mark, prob, box in zip(self.facial_landmarks, self.probabilities, self.boxes):
            if prob < self.config['min_confidence']:
                continue
            boxes.append(box)
            landmarks.append(land_mark)
            probabilities.append(prob)

        self._facial_landmarks = landmarks
        self._boxes = boxes
        self._probabilities = probabilities

        if get_pt:
            return [box_to_points(box) for box in self.boxes]
        else:
            return self.boxes
