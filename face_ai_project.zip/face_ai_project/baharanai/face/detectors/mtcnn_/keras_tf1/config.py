weights_file = None
min_face_size = 20
min_confidence = 0.99
scale_factor = 0.709
steps_threshold = None
