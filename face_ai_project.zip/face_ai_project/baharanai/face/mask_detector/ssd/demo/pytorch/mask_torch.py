from baharanai.face.mask_detector.ssd.pytorch.mask_pytorch import PytorchMask
import cv2
import time
mask=PytorchMask()
path=r'D:\myprojects\PycharmProjects\framework\baharanai\face\mask_detector\ssd\demo\keras\mask.png'
frame=cv2.imread(path)
frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
a=mask.detect_mask(frame)
print(a)
# for elements in a:
#     font = cv2.FONT_HERSHEY_SIMPLEX
#     mask_mode = elements['mask']
#     (x1, y1, x2, y2) = elements['box']
#     cv2.rectangle(frame, (x1, y1), (x2,  y2), 2)  # Get Face
#     overlay_text = " %s " % (mask_mode)
#     cv2.putText(frame, overlay_text, (x1, y1), font, 1, (255, 255, 255), 2, cv2.LINE_AA)
# cv2.imshow('frame', frame)
# cv2.waitKey(10000)

# cap = cv2.VideoCapture(0)
# height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
# width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
# fps = cap.get(cv2.CAP_PROP_FPS)
# fourcc = cv2.VideoWriter_fourcc(*'XVID')
# # writer = cv2.VideoWriter(output_video_name, fourcc, int(fps), (int(width), int(height)))
# total_frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
# if not cap.isOpened():
#     raise ValueError("Video open failed.")
# status = True
# idx = 0
# while status:
#     start_stamp = time.time()
#     status, img_raw = cap.read()
#     img_raw = cv2.cvtColor(img_raw, cv2.COLOR_BGR2RGB)
#     read_frame_stamp = time.time()
#     if (status):
#         mask.detect_mask(img_raw)
#         cv2.imshow('image', img_raw[:, :, ::-1])
#         cv2.waitKey(1)
#         inference_stamp = time.time()
#         # writer.write(img_raw)
#         write_frame_stamp = time.time()
#         idx += 1
#         print("%d of %d" % (idx, total_frames))
#         print("read_frame:%f, infer time:%f, write time:%f" % (read_frame_stamp - start_stamp,
#                                                                inference_stamp - read_frame_stamp,
#                                                                write_frame_stamp - inference_stamp))