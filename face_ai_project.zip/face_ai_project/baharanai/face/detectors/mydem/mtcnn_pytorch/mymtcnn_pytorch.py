from baharanai.face.detectors.mtcnn_.pytorch import MTCNNDetectorPyTorch
from baharanai.preprocessing.image import draw_rectangle, show_img, crop_face, get_biggest_box, save_img, read_image
from baharanai.preprocessing.image import cv2_frame_to_pil
from baharanai.preprocessing.image import box_to_points
import time
import cv2
#
# img_path = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mydem\data\my1.jpg'
# frame = read_image(img_path, lib='cv2', ret_rgb=True)
detector = MTCNNDetectorPyTorch(config_path=r'D:\myprojects\PycharmProjects\framework\baharanai\face\detectors\mydem\mtcnn_pytorch\config.json')
# image = cv2_frame_to_pil(frame, is_rgb=True)
# tic = time.time()
# boxes = detector.detect_faces(frame)
# toc = time.time()
# print(f'detect time:{toc - tic}')
# for box in boxes:
#     pt1, pt2 = box_to_points(box)
#     frame = draw_rectangle(frame, pt1, pt2, copy=False, color=(0, 255, 0), is_rgb=True)
# box, box_index = get_biggest_box(boxes)
# pt1, pt2 = box_to_points(box)
# face = crop_face(frame, pt1, pt2, )
# save_img(r'../../data/faces/abdi/abdi.jpg', face, is_rgb=True)
# show_img(frame, is_rgb=True)

# detector = MTCNNDetectorPyTorch()
vc = cv2.VideoCapture(0)
while True:
    ret, frame = vc.read()
    if not ret:
        print(':(')
        break
    image = cv2_frame_to_pil(frame, is_rgb=False)
    tic = time.time()
    boxes = detector.detect_faces(image)
    toc = time.time()
    print(f'detect time:{toc - tic}')
    for box in boxes:
        pt1, pt2 = box_to_points(box)
        frame = draw_rectangle(frame, pt1, pt2, copy=False, color=(0, 255, 0), is_rgb=False)
    cv2.imshow('',frame)
    if cv2.waitKey(1) & 0xff == ord('q'):
        break
