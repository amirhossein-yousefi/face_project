import cv2
from baharanai.face.detectors.main import FaceDetector
from baharanai.preprocessing.image import bgr2rgb, box_to_points


class HaarCascadeDetector(FaceDetector):
    def __init__(self, config=None, config_path=None):
        super(HaarCascadeDetector, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model = cv2.CascadeClassifier(self.config['model_path'])

    def preprocessing(self, frame, is_rgb=True):
        if not is_rgb:
            frame = bgr2rgb(frame)
        return frame

    def detect_faces(self, image, get_pt=False, **kwargs):

        frame = self.preprocessing(image)
        boxes = self._model.detectMultiScale(frame,scaleFactor=self.config['scalefactor'],minNeighbors=self.config['min_neighbors'])
        if len(boxes) != 0:
            self._boxes = boxes.tolist()
        else:
            self._boxes = []
        if get_pt:
            return [box_to_points(box) for box in self._boxes]
        else:
            return self.boxes


# if __name__ == '__main__':
#     from keras.applications.resnet_v2 import ResNet50V2
#
#     ResNet50V2(weights='imagenet')
