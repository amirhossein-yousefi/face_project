from baharanai.face.age.age_opencv.age_opencv import Age
from baharanai.face.detectors.haarcascade.opencv.haarcascade import HaarCascadeDetector
import cv2
path=r'/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/age/demo/1.jpg'
frame=cv2.imread(path)
age=Age()
conf_path=r'/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/age/demo/config.json'
detector=HaarCascadeDetector(config_path=conf_path)
boxes=detector.detect_faces(frame)
a=age.detect_age(frame,boxes[0])
print(a)
# for elements in a:
#     font = cv2.FONT_HERSHEY_SIMPLEX
#     age = elements['age']
#     (x, y, w, h) = elements['box']
#     cv2.rectangle(frame, (x, y), (x + w, y + h), 2)  # Get Face
#     overlay_text = " %s " % ( age)
# cv2.putText(frame, overlay_text, (x, y), font, 1, (255, 255, 255), 2, cv2.LINE_AA)
# cv2.imshow('frame', frame)
# cv2.waitKey(10000)


