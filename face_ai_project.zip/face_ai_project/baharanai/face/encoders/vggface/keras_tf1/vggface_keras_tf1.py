from keras_vggface.vggface import VGGFace
from keras_vggface.utils import preprocess_input
from baharanai.face.encoders.main.face_encoder import FaceEncoder
from baharanai.preprocessing.image import resize_img, img_to_array


class VGGFaceEncoder(FaceEncoder):
    def __init__(self, config=None, config_path=None):
        super(VGGFaceEncoder, self).__init__(subclass_path=__file__, config=config, config_path=config_path)

    def load_model(self):
        self._model = VGGFace(include_top=self.config['include_top'],
                              model=self.config['model'],
                              input_shape=self.config['input_shape'],
                              pooling=self.config['pooling'],
                              input_tensor=self.config['input_tensor'],
                              weights=self.config['weights'],
                              classes=self.config['classes'])

    def get_encoding(self, batch_face, batch_size=32, do_preprocess=False):
        if do_preprocess:
            batch_face = self.preprocess(batch_face)
        return self._model.predict(batch_face, batch_size=batch_size)

    def preprocess(self, batch_face, version=2):
        batch_face = [resize_img(face, self.config['input_shape'][:2]) for face in batch_face if
                      face.shape[:2] != tuple(self.config['input_shape'][:2])]
        batch_face = img_to_array(batch_face, dtype='float32')
        batch_face = preprocess_input(batch_face, version=version)
        return batch_face

    def load_encoder_info(self):
        """
        This method loads the general information which may be needed for model like output shape
        """
        self.model_info['output_shape'] = self.model.output.shape
