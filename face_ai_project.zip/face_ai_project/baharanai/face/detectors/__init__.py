def face_detector_loader(name, config=None, config_path=None):
    if name == 'mtcnn_keras_tf1':
        from baharanai.face.detectors.mtcnn_.keras_tf1.mtcnn_tf1 import MTCNNDetectorTF1
        face_detector = MTCNNDetectorTF1(config=config, config_path=config_path)
    elif name == 'mtcnn_pytorch':
        from baharanai.face.detectors.mtcnn_.pytorch.mtcnn_pytorch import MTCNNDetectorPyTorch
        face_detector = MTCNNDetectorPyTorch(config=config, config_path=config_path)
    elif name == 'haarcascade_opencv':
        from baharanai.face.detectors.haarcascade.opencv.haarcascade import HaarCascadeDetector
        face_detector = HaarCascadeDetector(config=config, config_path=config_path)
    elif name == 'ultra_light_pytorch':
        from baharanai.face.detectors.ultra_light.pytorch.ultra_light_pytorch import UltraLightDetectorPytorch
        face_detector = UltraLightDetectorPytorch(config=config, config_path=config_path)
    else:
        raise NotImplementedError('The requested detector is not implemented')
    return face_detector
