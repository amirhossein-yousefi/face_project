from baharanai.face.gender.gender_opencv.gender import Gender
from baharanai.face.detectors.haarcascade.opencv.haarcascade import HaarCascadeDetector

import cv2
path=r'/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/gender/demo/1.jpg'
frame=cv2.imread(path)
gender=Gender()
conf_path=r'/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/gender/demo/config.json'
detector=HaarCascadeDetector(config_path=conf_path)
boxes=detector.detect_faces(frame)
a=gender.detect_gender(frame,boxes[0])
print(a)

# for elements in a:
#     font = cv2.FONT_HERSHEY_SIMPLEX
#     gender = elements['gender']
#     (x, y, w, h) = elements['box']
#     cv2.rectangle(frame, (x, y), (x + w, y + h), 2)  # Get Face
#     overlay_text = " %s " % ( gender)
#     cv2.putText(frame, overlay_text, (x, y), font, 1, (255, 255, 255), 2, cv2.LINE_AA)
# cv2.imshow('frame', frame)
# cv2.waitKey(10000)
