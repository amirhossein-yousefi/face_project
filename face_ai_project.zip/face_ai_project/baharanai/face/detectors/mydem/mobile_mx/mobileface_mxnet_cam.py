import time
import torch
import cv2
import numpy as np
from baharanai.face.detectors.mobileface.mx_net.mobileface_mxnet import mobilefacedetectormxnet
from baharanai.preprocessing.image import draw_rectangle, box_to_points, cv2_frame_to_pil, read_image, show_img
from gluoncv.data.transforms import presets
import mxnet as mx
from mxnet import nd
####### detector cam test########
thresh=0.5
detector = mobilefacedetectormxnet()
img_short = 256
vc = cv2.VideoCapture(0)
while True:
    ret, frame = vc.read()
    if not ret:
        print(':(')
        break
    tic = time.time()
    from PIL import Image
    # frame=mx.image.imread(frame)
    result = detector.detect_faces(mx.nd.array(frame))
    ids, scores, bboxes = [xx[0].asnumpy() for xx in result]
    toc = time.time()
    print(f'detect time:{toc - tic}')
    h, w, c = frame.shape
    scale = float(img_short) / float(min(h, w))
    for i, bbox in enumerate(bboxes):
        if scores[i] < thresh:
            continue
        xmin, ymin, xmax, ymax = [int(x / scale) for x in bbox]
        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 3)
    cv2.imshow('', frame)
    if cv2.waitKey(1) & 0xff == ord('q'):
        break


########## detector test #############
img_path = r'C:\Users\Baharan\PycharmProjects\framework\baharanai\face\detectors\mydem\data\my3.jpg'
# thresh=0.5
# detector = mobilefacedetectormxnet()
# img_short = 256
# img = mx.img.imread(r'C:\Users\Baharan\Desktop\MobileFace\data\test\my1.jpg')
# result=detector.detect_faces(img)
# ids, scores, bboxes = [xx[0].asnumpy() for xx in result]
#
# im = cv2.imread(r'C:\Users\Baharan\Desktop\MobileFace\data\test\my1.jpg')
# h, w, c = im.shape
# scale = float(img_short) / float(min(h, w))
# for i, bbox in enumerate(bboxes):
#     if scores[i] <thresh:
#         continue
#     xmin, ymin, xmax, ymax = [int(x / scale) for x in bbox]
#     cv2.rectangle(im, (xmin, ymin), (xmax, ymax), (0, 255, 0), 3)
# cv2.imwrite('result_detect_v2.jpg', im)
# cv2.imshow('result_detect', im)
# cv2.waitKey(20000)

########landmark test #############
# detector.landmarks(img = cv2.imread(img_path))


############  alignment test#######################
# align_result=detector.align(img=cv2.imread(img_path))
# cv2.imshow('', align_result[0])
# cv2.waitKey(20000)

