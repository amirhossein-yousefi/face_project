from baharanai.face.detectors.mtcnn_.keras_tf1.mtcnn_tf1 import MTCNNDetectorTF1
import time
import cv2
from baharanai.preprocessing.image import draw_rectangle, show_img, crop_face, get_biggest_box, save_img, read_image,box_to_points,boxes_to_centers
# img_path=r'E:\myprojects\PycharmProjects\framework\baharanai\face\detectors\mydem\data\my1.jpg'
# img = read_image(img_path, lib='cv2', ret_rgb=True)
det=MTCNNDetectorTF1()
# boxes=det.detect_faces(img)
# for box in boxes:
#     # print(box)
#     pt1, pt2 = box_to_points(box)
#     img = draw_rectangle(img, pt1, pt2, copy=False, color=(0, 255, 0), is_rgb=True)
#
# box, box1_index = get_biggest_box(boxes, mode='width_height')
# pt1, pt2 = box_to_points(box)
# face = crop_face(img, pt1, pt2, )
# show_img(img, is_rgb=True)

######################cam#########################
vc = cv2.VideoCapture(0)
while True:
    ret, frame = vc.read()
    if not ret:
        print(':(')
        break
    tic = time.time()
    boxes = det.detect_faces(frame)
    toc = time.time()
    print(f'detect time:{toc - tic}')
    for box in boxes:
        pt1, pt2 = box_to_points(box)
        frame = draw_rectangle(frame, pt1, pt2, copy=False, color=(0, 255, 0), is_rgb=False)
    cv2.imshow('',frame)
    if cv2.waitKey(1) & 0xff == ord('q'):
        break

