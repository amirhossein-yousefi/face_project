from baharanai.preprocessing.utils import load_config


class FaceEncoder:
    def __init__(self, subclass_path, config=None, config_path=None):
        self.subclass_path = subclass_path
        self.config = load_config(config=config, config_path=config_path, base_path=subclass_path)

        self._model = None
        self._model_info = {}
        self.load_model()
        self.load_encoder_info()

    def load_model(self):
        """
            This method does not return anything it loads the encoder model and assigns it to self.model
        """
        raise NotImplementedError('implement model loading')

    def load_encoder_info(self):
        """
        This method loads the general information which may be needed for model like output shape
        # self._model_info['output_shape'] = self._model.output.shape
        """
        raise NotImplementedError('implement encodings process')

    def get_encoding(self, batch_face, do_preprocess, **kwargs):
        """
            returns the detected faces by model
            :param batch_face: a batch of faces to be encoded...
            :return: encodings of faces
        """
        raise NotImplementedError('implement encodings process')

    def preprocess(self, batch_face):
        """
        faces should be preprocessed before feeding to network, most of models like VGGFace have their own preprocess
        :param batch_face:
        :return:
        """
        raise NotImplementedError('implement preprocessing process')

    @property
    def model(self):
        return self._model

    @property
    def model_info(self):
        return self._model_info
