import os
from baharanai.preprocessing.image import read_image, get_biggest_box, crop_face, save_img, box_to_points
from baharanai.face.detectors import face_detector_loader
from baharanai.preprocessing.utils import load_config


class GetFaces:
    def __init__(self, config=None, config_path=None):
        self.config = load_config(config=config, config_path=config_path, base_path=__file__)
        self.face_detector = face_detector_loader(name=self.config['detector']['name'],
                                                  config=self.config['detector'].get('config'),
                                                  config_path=self.config['detector'].get('config_path'))

    def post_process_face(self, face):
        """
        I have no post_process in my mind right now :D
        :param face:
        :return:
        """
        return face

    def get_face(self, frame, crop_scale=1):
        boxes = self.face_detector.detect_faces(frame)
        if len(boxes):
            box, box_index = get_biggest_box(boxes)
            if box:
                if self.config['align']:
                    face = self.face_detector.align(frame, self.face_detector.facial_landmarks[box_index])
                else:
                    pt1, pt2 = box_to_points(box)
                    face = crop_face(frame, pt1, pt2, scale=crop_scale)
                face = self.post_process_face(face)
                return face
        return None

    def run(self):

        if self.config['input_mode'] == 'folder_id':
            for face_name in os.listdir(self.config['read_path']):
                face_folder_path = os.path.join(self.config['read_path'], face_name)
                frame_counter = 0
                for file_name in os.listdir(face_folder_path):
                    file_path = os.path.join(face_folder_path, file_name)
                    if self.config['video_input']:
                        # we shall delete this part and handle it to another api which just reads frames from video
                        # and passes the frames to this method?? to be discussed
                        raise Exception("video_input mode is not implemented yet")
                    else:
                        try:
                            frame = read_image(img_path=file_path, ret_rgb=True)
                            face = self.get_face(frame)
                            if face is not None:
                                save_folder = os.path.join(self.config['save_path'], face_name)
                                os.makedirs(save_folder, exist_ok=True)
                                face_path = os.path.join(save_folder, f'{face_name}_{frame_counter}.png')
                                res = save_img(face_path, face, is_rgb=True)
                                if res:
                                    print(face_path, ' saved')
                                else:
                                    print(face_path, 'not saved')
                            frame_counter += 1
                        except BaseException as error:
                            print(f'{file_path} is not a pick')
                            print(error)
        else:
            raise Exception("requested input_mode is not implemented yet, available [folder_id]")