from baharanai.face.emotion_detector.fer.keras.emotion import Emotion
from baharanai.face.detectors.haarcascade.opencv.haarcascade import HaarCascadeDetector
import cv2

img_path=r"/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/emotion_detector/demo/1.jpg"
frame=cv2.imread(img_path)
model=Emotion()
conf_path=r'/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/emotion_detector/demo/config.json'
detector=HaarCascadeDetector(config_path=conf_path)
faces = detector.detect_faces(frame)
a=()
(a,b,c,d)=faces[0]
e=(a,b,c,d)
a = model.detect_emotions(frame,e)
print(faces[0])
print(a)
print(e)
# cap=cv2.VideoCapture(0)
# while True:
#     ret, frame = cap.read()
#     if not ret:
#         print(':(')
#         break
#     faces = detector.detect_faces(frame)
#     a = model.detect_emotions(frame,faces[0])
#     print(a)
#     for elements in a:
#         font = cv2.FONT_HERSHEY_SIMPLEX
#         emotion_mode = elements['emotion']
#         (x, y, w, h) = elements['box']
#         cv2.rectangle(frame, (x, y), (x + w, y + h), 2)  # Get Face
#         overlay_text = " %s " % ( emotion_mode)
#         cv2.putText(frame, overlay_text, (x, y), font, 1, (255, 255, 255), 2, cv2.LINE_AA)
#     cv2.imshow('frame', frame)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break
