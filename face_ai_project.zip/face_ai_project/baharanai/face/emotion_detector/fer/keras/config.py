model_path=r"/home/amirhossein/Documents/myfiles/myprojects/PycharmProjects/framework/baharanai/face/emotion_detector/fer/keras/fer2013_mini_XCEPTION.102-0.66.hdf5"
